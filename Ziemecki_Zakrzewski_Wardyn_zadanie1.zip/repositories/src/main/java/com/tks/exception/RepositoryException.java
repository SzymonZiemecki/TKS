package com.tks.exception;

public class RepositoryException extends Exception {
    public RepositoryException(String message) {
        super(message);
    }
}
