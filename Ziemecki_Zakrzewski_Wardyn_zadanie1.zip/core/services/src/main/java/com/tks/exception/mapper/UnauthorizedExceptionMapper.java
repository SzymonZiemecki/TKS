package com.tks.exception.mapper;

public class UnauthorizedExceptionMapper {
}
