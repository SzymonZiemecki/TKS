import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.shaded.com.fasterxml.jackson.core.JsonProcessingException;

@Testcontainers
public class HealthCheckVerifier extends TestContainerInitializer{
    @Test
    public void createOrderTest() throws InterruptedException, JsonProcessingException {

    }
}
