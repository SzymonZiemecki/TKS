package com.tks.dto;

public enum UserType {
    ADMIN, BASEUSER, MANAGER
}
