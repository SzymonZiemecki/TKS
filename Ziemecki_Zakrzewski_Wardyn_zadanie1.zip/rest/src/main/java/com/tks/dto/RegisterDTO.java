package com.tks.dto;

public class RegisterDTO {
}
